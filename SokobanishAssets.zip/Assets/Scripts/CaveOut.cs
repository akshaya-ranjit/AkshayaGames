using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class CaveOut : MonoBehaviour
{
    // Start is called before the first frame update
    public Tilemap theCave;
    public Transform cTrigger;
    public int totOutry = 0;

    public static CaveOut takeIt;

    private void Awake(){
        takeIt = this;
    }

    public int totOut(){
        return totOutry;
    }


    // void Update(){
    //     if (totOutry%2 == 0){
    //         ChangeColor();
    //     }else{
    //         theCave.color = new Color(1,1,1,1);
    //     }
    // }
    // public void ChangeColor(){
    //     theCave.color = new Color (1,1,1,0.75f);
    // }

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("something hit");
        if(other.gameObject.CompareTag("Player")){
            totOutry+=1;
            //Debug.Log("rock in cave!");
            Debug.Log("out: "+ totOutry);
        }
    }
}
