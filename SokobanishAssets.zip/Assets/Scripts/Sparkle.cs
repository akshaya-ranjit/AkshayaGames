using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Sparkle : MonoBehaviour
{
    public Animator anim;
    private int count = 0;
    // Start is called before the first frame update
    void Start()
    {
        anim.SetBool("isSparkle", false);
    }

    // Update is called once per frame
    void Update(){
        if(anim.GetBool("isSparkle")){
            count +=1;
        }
        if (count > 200){
            if(SceneManager.GetActiveScene().name == "L1"){
                SceneManager.LoadScene("L2");
            }else if(SceneManager.GetActiveScene().name == "L2"){
                SceneManager.LoadScene("L3");
            }else if(SceneManager.GetActiveScene().name == "L3"){
                SceneManager.LoadScene("Congrats");
            }
            
        }

    }

    /// <summary>
    /// Sent when an incoming collider makes contact with this object's
    /// collider (2D physics only).
    /// </summary>
    /// <param name="other">The Collision2D data associated with this collision.</param>
    private void OnCollisionEnter2D(Collision2D other)
    {
        Debug.Log("something hit");
        if(other.gameObject.CompareTag("Rock")){
            Debug.Log("in fairy ring!");
            anim.SetBool("isSparkle", true);
        }
    }

    //private void /// <summary>
    /// Sent when another object enters a trigger collider attached to this
    /// object (2D physics only).
    /// </summary>
    /// <param name="other">The other Collider2D involved in this collision.</param>
    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("something hit");
        if(other.gameObject.CompareTag("Rock")){
            Debug.Log("in fairy ring!");
            anim.SetBool("isSparkle", true);
        }
    }
}
