using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
//using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class GameManager : MonoBehaviour
{
    public Button restart;
    public string currentSceneName;
    // Start is called before the first frame update
    void Start()
    {
        currentSceneName = SceneManager.GetActiveScene().name;
        Debug.Log(currentSceneName);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void onRestart(){
        SceneManager.LoadScene(currentSceneName);
    }
}
