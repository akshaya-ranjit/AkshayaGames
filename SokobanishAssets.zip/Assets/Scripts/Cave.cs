using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Cave : MonoBehaviour
{
    // Start is called before the first frame update
    public Tilemap theCave;
    public GameObject inTrig;
    public GameObject outTrig;
    public Transform player;
    public LayerMask caveFloor;
    private int totalEntry = 0;
    private bool PlayerInCave = false;
    public float tp = 0.75f;


    void Update(){
        // if (Physics2D.OverlapCircle(player.position, 1f, caveFloor)){
        if(PlayerInCave){
            Debug.Log("overlap exists");
            ChangeColor();
        }else{
            theCave.color = new Color(1,1,1,1);
        }
        // totalEntry = outTrig.GetComponent<CaveOut>().totOutry + inTrig.GetComponent<CaveIn>().totEntry;
        // if (totalEntry%2 == 1){
        //     ChangeColor();
        // }
    }
    public void ChangeColor(){
        theCave.color = new Color (1,1,1,tp);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("something hit");
        if(other.gameObject.CompareTag("Player")){
            totalEntry+=1;
            PlayerInCave = true;
            Debug.Log("rock in cave!");
            //Debug.Log(totalEntry);
        }
    }

    private void OnTriggerExit2D(Collider2D other) {
        if(other.gameObject.CompareTag("Player")){
            totalEntry+=1;
            PlayerInCave = false;
            Debug.Log("rock out of cave!");
            //Debug.Log(totalEntry);
        }
    }
}
