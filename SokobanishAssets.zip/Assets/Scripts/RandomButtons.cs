using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RandomButtons : MonoBehaviour
{

    public void toMM(){
        SceneManager.LoadScene("MainMenu");
    }

    public void cMon(){
        SceneManager.LoadScene("L1");
    }

    public void toIntro(){
        SceneManager.LoadScene("Intro");
    }
}
