using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MMMan : MonoBehaviour
{
    public GameObject instructions;
    public GameObject levelPan;
    
    void Start(){
        instructions.SetActive(false);
        levelPan.SetActive(false);
    }
    public void openInstructions(){
        instructions.SetActive(true);
    }

    public void closeInstructions(){
        instructions.SetActive(false);
    }

    public void openLevels(){
        levelPan.SetActive(true);
    }

    public void closeLevels(){
        levelPan.SetActive(false);
    }

    public void openLevel1(){
        SceneManager.LoadScene("L1");
    }

    public void openLevel2(){
        SceneManager.LoadScene("L2");
    }

    public void openLevel3(){
        SceneManager.LoadScene("L3");
    }


}
