using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;


public class CaveIn : MonoBehaviour
{
    public Tilemap theCave;
    public Transform cTrigger;
    public int totEntry = 0;
    public static CaveIn takeIt;

    private void Awake(){
        takeIt = this;
    }
    // void Update(){
    //     if (totEntry%2 == 1){
    //         ChangeColor();
    //     }else{
    //         theCave.color = new Color(1,1,1,1);
    //     }
    // }
    // public void ChangeColor(){
    //     theCave.color = new Color (1,1,1,0.75f);
    // }

    public int totIn(){
        return totEntry;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("something hit");
        if(other.gameObject.CompareTag("Player")){
            totEntry+=1;
            //Debug.Log("rock in cave!");
            Debug.Log(totEntry);
        }
    }
}