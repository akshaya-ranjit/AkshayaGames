using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    private Vector2 movement;
    Animator animator;

    void Start(){
        animator = GetComponent<Animator>();
    }
    
    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.Normalize(movement) * speed * Time.deltaTime);
    }

    private void FixedUpdate(){
        animator.SetFloat("xVelocity", movement.x);
        //Debug.Log("xVel: " + animator.GetFloat("xVelocity"));
        animator.SetFloat("yVelocity", movement.y);
        //Debug.Log("yVel: " + animator.GetFloat("yVelocity"));
        if(movement.x ==0 && movement.y==0){
            animator.SetBool("isIdle", true);
            animator.SetFloat("Blend", 0.5f);
        }else if(movement.x!=0){
            animator.SetBool("isIdle", false);
            animator.SetFloat("Blend", 0.25f);
        }else if(movement.y!=0){
            animator.SetBool("isIdle", false);
            animator.SetFloat("Blend", 1f);
        }
        
    }

    void OnWASD(InputValue value){
        movement = value.Get<Vector2>();
        
    }
    
}
