using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public Sprite[] cardSprites;
    int[] cardValues = new int[53];
    int currentIndex = 0;
    // Start is called before the first frame update
    void Start()
    {
        GetCardValues();
        Shuffle();
    }

    // Update is called once per frame
    void GetCardValues(){
        int val = 0;
        for(int i = 0; i < cardSprites.Length; i++){
            val = i;
            val %= 13;
            if(val>10 || val==0){
                val = 10;
            }
            cardValues[i] = val++;
            //figure out why val++, if something is wrong with my score, this is the first place I'm looking
        }
        currentIndex = 1;
    }

    public void Shuffle(){
        for(int i = cardSprites.Length - 1; i>0; --i){
                int j = Mathf.FloorToInt(UnityEngine.Random.Range(00f, 1.0f) * cardSprites.Length - 1) + 1;
                if(i!=0 && j!=0){
                    Sprite face = cardSprites[i];
                    cardSprites[i] = cardSprites[j];
                    cardSprites[j] = face;

                    int iVal = cardValues[i];
                    cardValues[i] = cardValues[j];
                    cardValues[j] = iVal;
                } 
            }

        currentIndex = 1;
    }

    public int DealCard(CardScript cardScript){
        cardScript.SetSprite(cardSprites[currentIndex]);
        cardScript.SetVal(cardValues[currentIndex++]);
        return cardScript.GetVal();
    }
    public Sprite GetCardBack(){
        return cardSprites[0];
    }
}
