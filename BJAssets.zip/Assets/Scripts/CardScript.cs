using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardScript : MonoBehaviour
{
    public int val; // change to private
    public int GetVal(){    
        return val; 
    }

    public void SetVal(int newVal){
        val = newVal;
    }

    public void SetSprite(Sprite newSprite){
        gameObject.GetComponent<SpriteRenderer>().sprite = newSprite;
    }

    public void Reset(){
        Sprite back = GameObject.Find("CardTop").GetComponent<NewBehaviourScript>().GetCardBack();
        gameObject.GetComponent<SpriteRenderer>().sprite = back;
        val = 0;
    }
}
