using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayingScript : MonoBehaviour
{
    public CardScript cS;
    public NewBehaviourScript sS;
    // Start is called before the first frame update
    public int handVal;
    public GameObject[] hand;
    public int cardIndex = 0;
    public int aceCount = 0;
    public int numCards = 0;
    List<CardScript> aces = new List<CardScript>();
    void Start()
    {
        sS = GameObject.Find("CardTop").GetComponent<NewBehaviourScript>();
    }

    public void StartHand(){
        GetCard();
        GetCard();
    }

    // Update is called once per frame
    public int GetCard()
    {
        //Debug.Log("card inddex" + cardIndex);
        int cardVal = sS.DealCard(hand[cardIndex].GetComponent<CardScript>());
        hand[cardIndex].GetComponent<Renderer>().enabled = true;
        handVal += cardVal;
        if(cardVal == 1){
            aces.Add(hand[cardIndex].GetComponent<CardScript>());
        }
        cardIndex++;
        numCards++;
        return handVal;
    }

    public void AceMath(){
        foreach (CardScript ace in aces){
            if(handVal + 10 < 22 && ace.GetVal() == 1){
                ace.SetVal(11);
                handVal += 10;
            }else if(handVal > 21 && ace.GetVal() == 1){
                ace.SetVal(1);
                handVal -= 10;
            }
        }
    }
}
