using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Security;
using System.Xml.Serialization;
using TMPro;
using UnityEditor;
//using UnityEditor.Build;
//using UnityEditor.Tilemaps;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public Button dealButton;
    public Button hitButton;
    public Button standButton;
    public Button restartButton;
    public Button deckButton;
    public Button quitB;
    public PlayingScript player;
    public PlayingScript dealer;
    public TMP_Text standButtonText;
    public TMP_Text restartButtonText;
    private int standClicks = 0;
    public TMP_Text scoreTxt;
    public TMP_Text dealerHandTxt;
    public TMP_Text gamePointsTxt;
    public GameObject hiderCard;
    private Animator anim;
    public GameObject DYW;
    public int pWins = 0;
    public int dWins = 0;
    private Boolean inEndSequence = false;
    
    // Start is called before the first frame update
    void Start()
    {
        dealButton.onClick.AddListener(() => DealClicked());
        hitButton.onClick.AddListener(() => HitClicked());
        //hitButton2.onClick.AddListener(() => HitClicked());
        standButton.onClick.AddListener(() => StandClicked());
        restartButton.onClick.AddListener(() => RestartClicked());
        deckButton.onClick.AddListener(() => ReplayClicked());
        quitB.onClick.AddListener(() => QuitGame());
        hitButton.gameObject.SetActive(false);
        standButton.gameObject.SetActive(false);
        dealerHandTxt.gameObject.SetActive(false);
        gamePointsTxt.gameObject.SetActive(false);
        DYW.SetActive(false);

        anim = DYW.GetComponent<Animator>();
        anim.SetBool("isWin", false);
        anim.SetBool("isLose", false);
        anim.SetFloat("WinNum", 0);
    }

    // Update is called once per frame
    private void QuitGame()
    {
        SceneManager.LoadScene("Main Menu");
    }

    private void DealClicked(){
        player.StartHand();
        dealer.StartHand();
        Debug.Log("Deal clicked!");
        scoreTxt.text = "Hand: " + player.handVal.ToString();
        dealerHandTxt.text = "Dealer Hand: " + dealer.handVal.ToString();
        dealButton.gameObject.SetActive(false);
        deckButton.gameObject.SetActive(false);
        hitButton.gameObject.SetActive(true);
        standButton.gameObject.SetActive(true);
        standButtonText.text = "STAND";
    }

    private void HitClicked(){
        if(player.numCards <= 8){
            player.GetCard();
        }
        scoreTxt.text = "Hand: " + player.handVal.ToString();
        if(player.handVal > 21){
            EndFunk2();
        }
        Debug.Log("Hit clicked!");
    }

    private void RestartClicked(){
        string currentSceneName = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(currentSceneName);
    }

    private void ReplayClicked(){
        if(inEndSequence){
            SetGamePoints(pWins, dWins);
            ReStart();
        } 
    }

    private void HitDealer(){
        while(dealer.handVal < 16 && dealer.cardIndex <8){
            dealer.GetCard();
        }
        dealerHandTxt.text = "Dealer Hand: " + dealer.handVal.ToString();
        if(dealer.handVal > 21){
            EndFunk2();
        }
    }

    private void StandClicked(){
        standClicks++;
        if(standClicks >1){
            standButton.gameObject.SetActive(false);
            EndFunk1();
        } 
        HitDealer();
        Debug.Log("Stand clicked!");
        standButtonText.text = "CALL";
    }

    private void EndFunk1(){
        hiderCard.SetActive(false); //Destroy(hiderCard);
        dealerHandTxt.gameObject.SetActive(true);
        deckButton.gameObject.SetActive(true);
        inEndSequence = true;
        standButton.gameObject.SetActive(false);
        hitButton.gameObject.SetActive(false);
        restartButtonText.text = "click deck to\nplay again";
        DYW.SetActive(true);
        if(dealer.handVal > player.handVal){
            Debug.Log("You lose! womp womp");
            //anim.SetBool("isLose", true);
            anim.SetFloat("WinNum", (float)-0.05);
            Debug.Log("should be Lose Animation");
            //anim LOSE
            dWins++;
        }else if (dealer.handVal > player.handVal){
            Debug.Log("Draw...");
            //anim DRAW
        }else if (dealer.handVal < player.handVal){
            Debug.Log("You win! Woohoo!!");
            //anim.SetBool("isWin", true);
            anim.SetFloat("WinNum", 1);
            Debug.Log("should be Win Animation");
            pWins++; 
        }
        SetGamePoints(pWins, dWins);

        //add quit and restart (click Deck buttons)
    }

    private void EndFunk2(){

        hiderCard.SetActive(false); //Destroy(hiderCard);
        deckButton.gameObject.SetActive(true);
        inEndSequence = true;
        standButton.gameObject.SetActive(false);
        hitButton.gameObject.SetActive(false);
        dealerHandTxt.gameObject.SetActive(true);
        DYW.SetActive(true);
        restartButtonText.text = "click deck to\nplay again";
        if(dealer.handVal > 21){
            Debug.Log("Dealer Bust!! You WIN! woohoo!!");
            //anim.SetBool("isWin", true);
            anim.SetFloat("WinNum", 1);
            Debug.Log("should be Win Animation");
            pWins++;
        }else if(player.handVal > 21){
            Debug.Log("Bust!! You LOST! womp womp");
            //anim.SetBool("isLose", true);
            anim.SetFloat("WinNum", (float)-0.05);
            Debug.Log("should be Lose Animation");
            //animate BUST
            dWins++;
        }
    }

    private void ReStart(){
        DYW.SetActive(false);
        anim.SetBool("isWin", false);
        anim.SetBool("isLose", false);
        anim.SetFloat("WinNum", 0);
        hiderCard.SetActive(true);
        //replayTxt.gameObject.SetActive();
        foreach (GameObject card in player.hand){
            card.GetComponent<CardScript>().Reset();
        }
        foreach (GameObject card in dealer.hand){
            card.GetComponent<CardScript>().Reset();
        }
        player.handVal = 0;
        scoreTxt.text = "Hand: " + player.handVal.ToString();
        dealer.handVal = 0;
        dealerHandTxt.gameObject.SetActive(false);
        GameObject.Find("CardTop").GetComponent<NewBehaviourScript>().Shuffle();
        dealer.cardIndex = 0;
        player.cardIndex = 0;
        player.numCards = 0;
        dealer.numCards = 0;

        dealButton.gameObject.SetActive(true);
        hitButton.gameObject.SetActive(false);
        deckButton.gameObject.SetActive(false);
        standClicks = 0;
        restartButtonText.text = "RESTART";
        standButtonText.text = "STAND";
        standButton.gameObject.SetActive(false);
    }

    private void SetGamePoints(int playerWins, int dealerWins){
        pWins = playerWins;
        dWins = dealerWins;
        gamePointsTxt.text = "Dealer: " + dealerWins.ToString() + "\nPlayer: " + playerWins;
        gamePointsTxt.gameObject.SetActive(true);
    }
}
