using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Xml.Serialization;

public class MainMenuHandler : MonoBehaviour
{

    public Button playB;
    public Button infoB;
    public Button settingsB;
    public Button setBack;
    public Button blueCard;
    public Button redCard;
    public GameObject settingsPan;
    public GameObject HTP1;
    public Button HTP1BackB;
    public Button HTP1NextB;
    public GameObject HTP2;
    public Button HTP2BackB;
    public Button HTP2NextB;
    public GameObject HTP3;
    public Button HTP3BackB;
    public string desireScene = "GreenPlay";
    

    // Start is called before the first frame update
    void Start()
    {
        playB.onClick.AddListener(() => PlayClicked());
        infoB.onClick.AddListener(() => InfoClicked());
        settingsB.onClick.AddListener(() => SettingsClicked());
    }

    // Update is called once per frame
    private void PlayClicked(){
        SceneManager.LoadScene(desireScene);
    }

    private void InfoClicked(){
        HTP1.SetActive(true);
        HTP1BackB.onClick.AddListener(() => HTP1BackClicked());
        HTP1NextB.onClick.AddListener(() => HTP1NextClicked());
    }

    private void HTP1BackClicked(){
        HTP1.SetActive(false);
    }

    private void HTP1NextClicked(){
        HTP1.SetActive(false);
        HTP2.SetActive(true);
        HTP2BackB.onClick.AddListener(() => HTP2BackClicked());
        HTP2NextB.onClick.AddListener(() => HTP2NextClicked());
    }

    private void HTP2BackClicked(){
        HTP2.SetActive(false);
        HTP1.SetActive(true);
        HTP1BackB.onClick.AddListener(() => HTP1BackClicked());
        HTP1NextB.onClick.AddListener(() => HTP1NextClicked());
    }

    private void HTP2NextClicked(){
        HTP2.SetActive(false);
        HTP3.SetActive(true);
        HTP3BackB.onClick.AddListener(() => HTP3BackClicked());
    }

    private void HTP3BackClicked(){
        HTP3.SetActive(false);
        HTP2.SetActive(true);
        HTP2BackB.onClick.AddListener(() => HTP2BackClicked());
        HTP2NextB.onClick.AddListener(() => HTP2NextClicked());
    }




    private void SettingsClicked(){
        settingsPan.SetActive(true);
        setBack.onClick.AddListener(() => SetBackClicked());
        blueCard.onClick.AddListener(() => BlueClicked());
        redCard.onClick.AddListener(() => RedClicked());

    }

    private void SetBackClicked(){
        settingsPan.SetActive(false);
    }

    private void BlueClicked(){
        desireScene = "GreenPlay";
    }

    private void RedClicked(){
        desireScene = "RedPlay";
    }
}
